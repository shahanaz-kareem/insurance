@extends('templates.sidebar')
